# encoding: UTF-8
# 5H_Tool_Nhua_Rong.rb
# Root loader/register file for SketchUp Extension Manager / RBZ / RBE signing
# Version: 1.0.163

require 'sketchup.rb'
require 'extensions.rb'

module FiveH
  module ToolNhuaRong
    EXTENSION_ID      = '5H_Tool_Nhua_Rong'.freeze unless const_defined?(:EXTENSION_ID)
    EXTENSION_NAME    = '5H_Tool Nhựa Rỗng'.freeze unless const_defined?(:EXTENSION_NAME)
    EXTENSION_VERSION = '1.0.163'.freeze unless const_defined?(:EXTENSION_VERSION)

    unless const_defined?(:EXTENSION)
      # Không ghi đuôi .rb/.rbe ở đây. Sau khi ký/mã hóa, SketchUp sẽ tự tìm main.rbe.
      EXTENSION = SketchupExtension.new(EXTENSION_NAME, File.join(EXTENSION_ID, 'main'))
      EXTENSION.creator     = '5H'.freeze
      EXTENSION.version     = EXTENSION_VERSION
      EXTENSION.description = 'Bộ công cụ 5H_Tool Nhựa Rỗng: móc nhựa, khấu ngàm, khấu âm dương, bản lề, cắt 2 đầu, đánh dấu cạnh, nhãn và nesting.'.freeze
      EXTENSION.copyright   = '2026 5H'.freeze
    end

    unless file_loaded?(__FILE__)
      Sketchup.register_extension(EXTENSION, true)
      file_loaded(__FILE__)
    end
  end
end
